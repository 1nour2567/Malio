# 数模论文写作规范

## 摘要结构（300-500字）

```
[问题背景一句话] + [针对问题X，构建了Y模型] + [针对问题X，采用了Y方法]
+ [结果表明...] + [关键数字] + [灵敏度分析验证稳健性]
```

### 示例（CMC 风格）
> 围绕中老年高血脂症的风险识别与个体化干预问题，本文构建了一个中西医结合的分层建模框架。
> 针对问题一，采用 Spearman-互信息-PLS 三维融合+熵权法筛选关键指标，前5位指标为 TC、TG、血尿酸、HDL-C 和 ADL吃饭。
> 针对问题二，构建三级融合预警模型（临床规则 → LightGBM → 中医修正），5折交叉验证 AUC 达 0.89。
> 针对问题三，建立有限时域动态规划模型，94.6% 患者最优频率收敛于 ≥9 次/周。
> 灵敏度分析表明模型具有较强稳健性。

## 假设说明（4-6条）

| # | 假设 | 合理性 |
|---|------|--------|
| 1 | 样本数据真实反映总体人群特征 | 数据来源可靠，样本量充足 |
| 2 | 各体质得分独立 | 体质判定标准不同维度的独立性已被临床验证 |
| 3 | 患者依从性为 100% | 简化模型，后续可通过折扣因子修正 |

## 符号说明（表格）

| 符号 | 含义 | 单位 |
|------|------|------|
| $N_i$ | 第 i 个样本的血脂异常项数 | 无量纲 |
| $\hat{p}_i$ | LightGBM 预测风险概率 | [0,1] |
| $w_j$ | 第 j 个指标的熵权权重 | [0,1] |

## 模型构建（核心部分）

写法模板：
1. **思路**：先讲直觉（"为什么这样做"），再讲公式
2. **公式**：编号 + 变量解释
3. **求解**：算法步骤或代码逻辑
4. **结果**：图表 + 一句话解读

## 问题重述

用自己的话重述题目，禁止直接粘贴赛题原文。写法：
- 第一段：大背景（1-2 句）
- 第二段：每个问题用自己的话概括（各 1 句）
- 第三段：本文做了什么 + 结构安排

## 各节字数分配建议（国赛，按 8000 字总）

| 节 | 建议字数 | 占比 |
|----|---------|------|
| 摘要 | 300-500 | — |
| 问题重述 | 150-200 | 2% |
| 问题分析 | 150-200 | 2% |
| 模型假设与符号说明 | 400-600 | 6% |
| 模型构建（每个问题） | 1000-1500 | 18% |
| 模型求解 | 600-800 | 9% |
| 结果分析 | 800-1000 | 12% |
| 灵敏度分析 | 600-800 | 9% |
| 模型评价与改进 | 400-600 | 6% |
| 参考文献 | 100-200 | 1% |

## 英文摘要（美赛必需）

```
**Summary**

[Background: 1-2 sentences describing the problem context.]

[For Problem 1, we constructed X model to... The key findings are...]

[For Problem 2, we adopted Y approach. Results show that...]

[For Problem 3, a Z framework was developed. The optimal solution...]

[Sensitivity analysis confirms the robustness of our models. Key numerical results: AUC = 0.XX, accuracy = XX%.]

**Keywords:** keyword1, keyword2, keyword3
```

## 模型评价与改进方向

### 模型优缺点（不空洞，针对具体方法）

写法模板：
```
（1）XXX 模型的优势在于...
（2）XXX 模型的局限在于...
（3）YYY 方法的优点...
（4）YYY 方法的不足...
```

禁止写"本文模型具有较好的准确性"这种无数据的话。每条必须带理由或数字。

### 改进方向
- 需收敛到具体的下一步行动，不是泛泛的"未来可以改进"
- 例如："若数据允许，可用随机效应模型替代固定效应，捕捉个体异质性"
- 列出 2-3 条即可

## 参考文献格式

### GB/T 7714（国赛）

```
期刊：
[1] 作者. 论文题目[J]. 期刊名, 年份, 卷号(期号): 起止页码.
例：[1] 张三, 李四. 基于机器学习的疾病预测模型综述[J]. 计算机学报, 2020, 43(5): 891-905.

书籍：
[2] 作者. 书名[M]. 版本. 出版地: 出版社, 年份.
例：[2] Bishop C M. Pattern Recognition and Machine Learning[M]. New York: Springer, 2006.
```

### APA 7th（美赛）

```
[1] Author, A. A., & Author, B. B. (Year). Title of article. Title of Periodical, Volume(Issue), pages. doi:xx.xxxx
[2] Author, C. C. (Year). Title of work: Capital letter also for subtitle. Publisher.
```

## 灵敏度分析

标准三板斧：
1. **参数扰动**：关键参数 ±10%/±20%，看结论是否翻转
2. **噪声测试**：输入加 5%/10%/20% 噪声，输出变化
3. **Bootstrap**：重采样 1000 次，看结果分布

**美赛增强版灵敏度：**
- **Morris 法** `[美赛]`：µ-σ 图区分参数的主效应和交互效应
- **Pareto 前沿敏感性** `[美赛]`：改变权重偏好，看前沿上最优解是否漂移

---

## 美赛英文写作

### Summary Sheet 模板 (独立一页)

```
**Summary**

[Background: 1-2 sentences describing the problem context.]

We developed [Model Name], a [type] model that [core innovation].

For Problem 1, [method + key finding + headline number]. Specifically, [details].

For Problem 2, we [adapted/extended the model to...]. Results show that [finding].

For Problem 3, [action — often a memo/scenario analysis].

Sensitivity analysis confirms [robustness claim]. The model achieves [R²/X% accuracy]
under [conditions].

**Keywords:** keyword1, keyword2, keyword3
```

### 正文常用句式

| 用途 | 句式 | 使用场景 |
|------|------|---------|
| 模型建立 | We constructed/formulated a [type] model to capture... | 每问开头 |
| 数学描述 | Let X denote... / The objective function is given by... | 公式前 |
| 求解过程 | The model was solved using [algorithm], implemented in [tool]. | 数学转代码 |
| 结果呈现 | Our results indicate/reveal/demonstrate that... | 结果段开头 |
| 数值强调 | Specifically, [variable] reaches [value] under [condition]. | 关键数字 |
| 灵敏度 | Sensitivity analysis reveals that [parameter] exerts the strongest influence on [output]. | 灵敏度段 |
| 模型对比 | Compared with [baseline], our model achieves a [X%] improvement in [metric]. | 方法对比 |
| 局限性 | Several limitations warrant consideration. First, [specific limitation]. | 结尾段 |
| 政策建议 | These findings suggest that policymakers should [action]. | 美赛 Problem 3 |

### Memo 写作 (美赛 Problem 3 常见)

格式：致旅游局/市政府的一页备忘录
```
**MEMORANDUM**

**To:** [Recipient, e.g., Juneau Tourist Council]
**From:** [Your Team]
**Date:** [Date]
**Subject:** [Policy recommendations based on model findings]

[1-2 paragraphs of key findings and actionable recommendations.]

Our model recommends:
1. [Specific action] — [Expected outcome in numbers]
2. [Specific action] — [Expected outcome in numbers]

[Closing sentence: offer to provide detailed technical report.]
```

### 美赛 vs 国赛 写作差异速查

| 维度 | 国赛/MathorCup | 美赛 MCM/ICM |
|------|-------------|------------|
| 摘要位置 | 正文第一页 | 独立 Summary Sheet |
| 摘要长度 | 300-500 字 | 半页到一页 |
| 正文语言 | 中文 | 英文 |
| 公式编号 | (1), (2)... | (1), (2)... 一致 |
| 图表标注 | 图1/表1, 中文标题 | Figure 1/Table 1, 英文标题 |
| 代码附录 | 完整放附录 | 仅关键片段，更多放 GitHub |
| 参考文献 | GB/T 7714 | APA 7th |
| 页数 | 30-60 | 20-30（含 Summary Sheet） |
| 迁移验证 | 不要求 | Problem 2 必做 |
| 政策建议 | 不常见 | Problem 3 必做 Memo |
