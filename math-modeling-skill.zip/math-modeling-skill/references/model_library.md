# 模型速查库

## 1. 特征筛选

### Spearman 秩相关
```python
from scipy.stats import spearmanr
corr, p_value = spearmanr(df['feature'], df['target'])
```

### 互信息
```python
from sklearn.feature_selection import mutual_info_classif
mi_scores = mutual_info_classif(X, y, random_state=42)
```

### 熵权法（客观赋权）
```python
def entropy_weight(X):
    P = X / X.sum(axis=0)
    P = np.clip(P, 1e-10, 1)
    e = -np.sum(P * np.log(P), axis=0) / np.log(len(X))
    w = (1 - e) / np.sum(1 - e)
    return w
```

### PLS（双响应联合）
```python
from sklearn.cross_decomposition import PLSRegression
pls = PLSRegression(n_components=2, scale=False)
pls.fit(X_scaled, y_combined)
# 结构载荷 = corr(X_i, 潜变量)
```

## 2. 分类模型

### LightGBM（推荐，快且效果好）
```python
import lightgbm as lgb
model = lgb.LGBMClassifier(
    n_estimators=1000, learning_rate=0.05,
    max_depth=6, num_leaves=31,
    is_unbalance=True,  # 处理类别不平衡
    random_state=42
)
# 5折交叉验证
from sklearn.model_selection import StratifiedKFold, cross_val_score
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
scores = cross_val_score(model, X, y, cv=cv, scoring='roc_auc')
```

### 类别不平衡处理
```python
# SMOTE
from imblearn.over_sampling import SMOTE
smote = SMOTE(random_state=42)
X_resampled, y_resampled = smote.fit_resample(X, y)

# class_weight
model = lgb.LGBMClassifier(class_weight='balanced')
```

### Logistic Regression（可解释性强）
```python
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
# 先标准化
X_scaled = StandardScaler().fit_transform(X)
model = LogisticRegression(random_state=42)
model.fit(X_scaled, y)
# 系数 = 特征贡献
coef = model.coef_[0]
```

## 3. 评价模型

### TOPSIS
```python
def topsis(matrix, weights):
    norm = matrix / np.sqrt((matrix**2).sum(axis=0))
    weighted = norm * weights
    ideal_best = weighted.max(axis=0)
    ideal_worst = weighted.min(axis=0)
    d_best = np.sqrt(((weighted - ideal_best)**2).sum(axis=1))
    d_worst = np.sqrt(((weighted - ideal_worst)**2).sum(axis=1))
    score = d_worst / (d_best + d_worst)
    return score
```

### AHP（层次分析法）
```python
# 判断矩阵 → 特征向量法求权重
eigenvalues, eigenvectors = np.linalg.eig(judgment_matrix)
max_eigenvalue = np.max(eigenvalues.real)
weights = eigenvectors[:, np.argmax(eigenvalues.real)].real
weights = weights / weights.sum()
# 一致性检验
CI = (max_eigenvalue - n) / (n - 1)
CR = CI / RI[n]  # RI查表
```

## 4. 优化模型

### 线性规划（PuLP）
```python
from pulp import LpProblem, LpVariable, LpMinimize, lpSum, value
prob = LpProblem("name", LpMinimize)
x = [LpVariable(f"x{i}", lowBound=0, cat='Integer') for i in range(n)]
prob += lpSum(c[i] * x[i] for i in range(n))  # 目标函数
for j in range(m):
    prob += lpSum(a[j][i] * x[i] for i in range(n)) <= b[j]  # 约束
prob.solve()
result = [value(x[i]) for i in range(n)]
```

### 动态规划（DP）
```python
# 有限时域 DP
def dp_value(t, state, memo={}):
    if t == T: return terminal_cost(state)
    if (t, tuple(state)) in memo: return memo[(t, tuple(state))]
    best = float('inf')
    for action in actions:
        next_state = transition(state, action)
        cost = immediate_cost(state, action, t) + dp_value(t+1, next_state, memo)
        if cost < best: best = cost
    memo[(t, tuple(state))] = best
    return best
```

## 5. 灵敏度分析

### 参数扰动法
```python
def sensitivity_analysis(model_func, param_names, base_values, delta=0.1):
    results = {}
    base = model_func(**base_values)
    for param in param_names:
        values = base_values.copy()
        values[param] = base_values[param] * (1 + delta)
        up = model_func(**values)
        values[param] = base_values[param] * (1 - delta)
        down = model_func(**values)
        results[param] = {'up_change': (up-base)/base, 'down_change': (down-base)/base}
    return results
```

### Bootstrap 稳健性
```python
def bootstrap_robustness(data, model_func, n_bootstrap=1000):
    results = []
    for _ in range(n_bootstrap):
        sample = data.sample(n=len(data), replace=True)
        results.append(model_func(sample))
    return np.mean(results), np.percentile(results, [2.5, 97.5])
```

## 6. 常用派生特征

### 派生特征示例（生物医学）
```python
df['non-HDL-C'] = df['TC'] - df['HDL-C']
df['AIP'] = np.log(df['TG'] / df['HDL-C'])
df['TC/HDL'] = df['TC'] / df['HDL-C']
df['异常项数'] = ((df['TC']>5.2).astype(int) + (df['TG']>1.7).astype(int) +
                  (df['LDL-C']>3.4).astype(int) + (df['HDL-C']<1.0).astype(int))
```

### 交叉特征
```python
# 领域变量间的交互项，需根据题目确定变量名
df['var1×var2'] = df['var1'] * df['var2']
df['var1×var3'] = df['var1'] * df['var3']
```

## 7. XGBoost / CatBoost

### XGBoost
```python
import xgboost as xgb
model = xgb.XGBClassifier(
    n_estimators=500, learning_rate=0.05,
    max_depth=6, subsample=0.8,
    colsample_bytree=0.8, random_state=42,
    use_label_encoder=False, eval_metric='logloss'
)
```

### CatBoost（类别特征原生支持）
```python
from catboost import CatBoostClassifier
cat_features = ['性别', '地区']  # 直接传类别列名或索引
model = CatBoostClassifier(
    iterations=500, learning_rate=0.05,
    depth=6, cat_features=cat_features,
    random_seed=42, verbose=0
)
```

## 8. 模型可解释性（SHAP）

```python
import shap

# 特征重要性（全局）
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X)
shap.summary_plot(shap_values, X, show=False)
plt.savefig('shap_summary.png', dpi=300)

# 单样本解释
shap.waterfall_plot(explainer(X.iloc[[0]]))

# 特征重要性排名
importance = np.abs(shap_values).mean(axis=0)
ranked = sorted(zip(X.columns, importance), key=lambda x: x[1], reverse=True)
for i, (feat, imp) in enumerate(ranked[:10]):
    print(f"{i+1}. {feat}: {imp:.4f}")
```

## 9. 超参数调优（Optuna）

```python
import optuna

def objective(trial):
    params = {
        'n_estimators': trial.suggest_int('n_estimators', 300, 2000),
        'max_depth': trial.suggest_int('max_depth', 3, 10),
        'num_leaves': trial.suggest_int('num_leaves', 15, 127),
        'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),
        'subsample': trial.suggest_float('subsample', 0.6, 1.0),
    }
    model = lgb.LGBMClassifier(**params, random_state=42, verbose=-1)
    scores = cross_val_score(model, X_train, y_train, cv=5, scoring='roc_auc')
    return scores.mean()

study = optuna.create_study(direction='maximize')
study.optimize(objective, n_trials=50, show_progress_bar=True)
print(study.best_params)
print(study.best_value)
```

## 10. 数据预处理代码

### 缺失值检测与填补
```python
# 缺失率报告
missing = df.isnull().sum()
missing_rate = (missing / len(df)).sort_values(ascending=False)
print(missing_rate[missing_rate > 0])

# 填补策略
from sklearn.impute import SimpleImputer, KNNImputer
num_cols = df.select_dtypes(include='number').columns
cat_cols = df.select_dtypes(include='object').columns

# 数值：中位数（偏态）或均值（正态）
df[num_cols] = SimpleImputer(strategy='median').fit_transform(df[num_cols])
# 类别：众数
df[cat_cols] = SimpleImputer(strategy='most_frequent').fit_transform(df[cat_cols])
```

### 异常值检测与处理
```python
def detect_outliers_iqr(df, col):
    Q1, Q3 = df[col].quantile(0.25), df[col].quantile(0.75)
    IQR = Q3 - Q1
    lower, upper = Q1 - 1.5 * IQR, Q3 + 1.5 * IQR
    return ((df[col] < lower) | (df[col] > upper)).sum(), lower, upper

# 盖帽法（winsorize）
from scipy.stats.mstats import winsorize
df['col'] = winsorize(df['col'], limits=(0.01, 0.01))  # 掐头去尾各1%
```

### 分布变换
```python
from scipy.stats import boxcox, yeojohnson

df['col_boxcox'], lam = boxcox(df['col'] + 1e-6)  # 只适用于正值
df['col_yeo'], lam = yeojohnson(df['col'])  # 可含零负值
```

## 11. 中文文本处理
```python
import jieba
import jieba.analyse

# 分词
doc = "患者主诉头晕胸闷，既往有高血压病史"
words = jieba.lcut(doc)

# 关键词提取（TF-IDF）
keywords = jieba.analyse.extract_tags(doc, topK=5, withWeight=True)

# TextRank
keywords_tr = jieba.analyse.textrank(doc, topK=5, withWeight=True)

# 批量 TF-IDF 向量化
from sklearn.feature_extraction.text import TfidfVectorizer
corpus = df['text_column'].tolist()
vectorizer = TfidfVectorizer(max_features=200, tokenizer=jieba.lcut)
X_text = vectorizer.fit_transform(corpus)
```

## 12. 智能优化算法

### 遗传算法 (GA)
```python
import numpy as np

def genetic_algorithm(fitness_func, bounds, pop_size=100, n_gen=200,
                       crossover_rate=0.8, mutation_rate=0.1):
    n_var = len(bounds)
    pop = np.random.uniform(low=[b[0] for b in bounds],
                            high=[b[1] for b in bounds], size=(pop_size, n_var))
    best_fitness = -np.inf
    best_solution = None
    for gen in range(n_gen):
        fitness = np.array([fitness_func(ind) for ind in pop])
        elite_idx = np.argmax(fitness)
        if fitness[elite_idx] > best_fitness:
            best_fitness, best_solution = fitness[elite_idx], pop[elite_idx].copy()
        prob = (fitness - fitness.min()) / (fitness.max() - fitness.min() + 1e-10)
        parents = pop[np.random.choice(pop_size, size=pop_size, p=prob / prob.sum())]
        offspring = parents.copy()
        for i in range(0, pop_size, 2):
            if np.random.random() < crossover_rate:
                alpha = np.random.random(n_var)
                offspring[i] = alpha * parents[i] + (1 - alpha) * parents[i+1]
                offspring[i+1] = alpha * parents[i+1] + (1 - alpha) * parents[i]
        mutation_mask = np.random.random((pop_size, n_var)) < mutation_rate
        offspring += mutation_mask * np.random.normal(0, 0.1, (pop_size, n_var))
        for j in range(n_var):
            offspring[:, j] = np.clip(offspring[:, j], bounds[j][0], bounds[j][1])
        pop = offspring
    return best_solution, best_fitness
```

### 粒子群优化 (PSO)
```python
def pso(objective_func, bounds, n_particles=50, n_iter=200, w=0.7, c1=1.5, c2=1.5):
    n_var = len(bounds)
    lb = np.array([b[0] for b in bounds])
    ub = np.array([b[1] for b in bounds])
    pos = np.random.uniform(lb, ub, (n_particles, n_var))
    vel = np.zeros((n_particles, n_var))
    p_best_pos = pos.copy()
    p_best_val = np.array([objective_func(p) for p in pos])
    g_best_idx = np.argmax(p_best_val)
    g_best_pos = p_best_pos[g_best_idx].copy()
    for _ in range(n_iter):
        r1, r2 = np.random.random(2)
        vel = w * vel + c1 * r1 * (p_best_pos - pos) + c2 * r2 * (g_best_pos - pos)
        pos += vel
        pos = np.clip(pos, lb, ub)
        cur_val = np.array([objective_func(p) for p in pos])
        improved = cur_val > p_best_val
        p_best_pos[improved] = pos[improved].copy()
        p_best_val[improved] = cur_val[improved]
        if np.max(cur_val) > p_best_val[g_best_idx]:
            g_best_idx = np.argmax(cur_val)
            g_best_pos = pos[g_best_idx].copy()
    return g_best_pos, objective_func(g_best_pos)
```

### 模拟退火 (SA)
```python
def simulated_annealing(objective_func, bounds, n_iter=1000, T_start=100, T_end=0.01):
    n_var = len(bounds)
    current = np.array([np.random.uniform(b[0], b[1]) for b in bounds])
    current_val = objective_func(current)
    best, best_val = current.copy(), current_val
    T = T_start
    for i in range(n_iter):
        candidate = current + np.array([np.random.normal(0, 0.1 * (bounds[j][1] - bounds[j][0]))
                                         for j in range(n_var)])
        candidate = np.clip(candidate, [b[0] for b in bounds], [b[1] for b in bounds])
        candidate_val = objective_func(candidate)
        delta = candidate_val - current_val
        if delta > 0 or np.random.random() < np.exp(delta / T):
            current, current_val = candidate, candidate_val
            if current_val > best_val:
                best, best_val = current.copy(), current_val
        T = T_start * (T_end / T_start) ** (i / n_iter)
    return best, best_val
```

## 13. 多目标优化 (NSGA-II)

```python
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.optimize import minimize
from pymoo.core.problem import Problem
import numpy as np

class TourismProblem(Problem):
    def __init__(self):
        super().__init__(n_var=3, n_obj=3, n_constr=2,
                         xl=np.array([0, 0, 0]),
                         xu=np.array([20000, 100, 100]))
    def _evaluate(self, x, out):
        tourists, tax_rate, invest_pct = x[:, 0], x[:, 1], x[:, 2]
        revenue = tourists * 375 - x[:, 1] * tourists * 10
        env_impact = tourists * 0.5 + 100 * (x[:, 2] < 30)
        satisfaction = 100 - tourists * 0.002 + x[:, 2] * 0.3
        out["F"] = np.column_stack([-revenue, env_impact, -satisfaction])
        out["G"] = np.column_stack([tourists - 16000, 5000 - tourists])

algorithm = NSGA2(pop_size=100, sampling=FloatRandomSampling(),
                  crossover=SBX(prob=0.9, eta=15), mutation=PM(prob=0.1, eta=20))
res = minimize(TourismProblem(), algorithm, ('n_gen', 200), seed=42, verbose=False)
```

## 14. 系统动力学 (ODE)

```python
from scipy.integrate import solve_ivp

def tourism_dynamics(t, y, params):
    T, E, S = y
    r1, k2, k3, k4, k5, k6 = params
    dT = r1 * T * (1 - T / 16000) - k2 * T * (1 - E / 100)
    dE = -k3 * T + k4 * (100 - E)
    dS = -k5 * T / 16000 + k6 * (E / 100)
    return [dT, dE, dS]

sol = solve_ivp(tourism_dynamics, [0, 10], [10000, 80, 60],
                args=([0.05, 0.3, 0.02, 0.1, 0.5, 0.3, 0.4],),
                method='RK45', dense_output=True)
```

## 15. 物理反演 (Bayesian Inversion)

```python
import pymc as pm

with pm.Model() as wear_model:
    age = pm.Uniform('age', lower=0, upper=500)
    daily_traffic = pm.Uniform('daily_traffic', lower=0, upper=5000)
    hardness = pm.Normal('hardness', mu=3e9, sigma=1e8)
    K, P = 1e-13, 700
    S = daily_traffic * 365 * age * 0.3
    mu_wear = K * P * S / hardness
    sigma = pm.HalfNormal('sigma', sigma=1)
    wear_obs = pm.Normal('wear_obs', mu=mu_wear, sigma=sigma, observed=wear_depth_data)
    trace = pm.sample(2000, tune=1000, target_accept=0.9)
pm.summary(trace)
```

## 16. 几何建模

```python
# SAT 碰撞检测
def sat_collision(rect1, rect2):
    axes = []
    for rect in [rect1, rect2]:
        for i in range(4):
            edge = rect[(i+1)%4] - rect[i]
            axes.append(np.array([-edge[1], edge[0]]))
    for axis in axes:
        axis = axis / np.linalg.norm(axis)
        p1, p2 = [np.dot(c, axis) for c in rect1], [np.dot(c, axis) for c in rect2]
        if max(p1) < min(p2) or max(p2) < min(p1):
            return False
    return True

# Delaunay 三角化体积
from scipy.spatial import Delaunay
tri = Delaunay(points[:, :2])
volume = sum(abs(np.dot(pts[s[0]], np.cross(pts[s[1]], pts[s[2]]))) / 6
             for s in tri.simplices)

# 螺线弧长
def spiral_arc_length(theta_end, a=0.1, n_steps=1000):
    theta = np.linspace(0, theta_end, n_steps)
    dr_dtheta = np.gradient(a * theta, theta)
    integrand = np.sqrt((a * theta)**2 + dr_dtheta**2)
    return np.trapz(integrand, theta)
```

## 17. 零膨胀计数模型

```python
import statsmodels.api as sm
import statsmodels.formula.api as smf

# Hurdle: Logit(零vs正) + 截断泊松(正数量)
df['medal_binary'] = (df['total_medals'] > 0).astype(int)
logit = smf.logit('medal_binary ~ athletes + gdp + host', data=df).fit()
positive = df[df['total_medals'] > 0]
poisson = smf.glm('total_medals ~ athletes + gdp + host', data=positive,
                  family=sm.families.Poisson()).fit()
df_new['pred_medals'] = logit.predict(df_new) * poisson.predict(df_new)

# ZINB (一步到位)
from statsmodels.discrete.count_model import ZeroInflatedNegativeBinomialP
zinb = ZeroInflatedNegativeBinomialP(
    df['total_medals'], df[['athletes', 'gdp', 'host']],
    exog_infl=df[['athletes']]).fit()
```

## 18. 统计检验速查

```python
from scipy.stats import f_oneway, shapiro, mannwhitneyu
from sklearn.metrics import silhouette_score
from statsmodels.stats.outliers_influence import variance_inflation_factor

stat, p = f_oneway(g1, g2, g3)           # ANOVA
stat, p = mannwhitneyu(g1, g2)           # Mann-Whitney U
stat, p = shapiro(data)                  # 正态性检验

for k in range(2, 8):                    # Silhouette 选 K
    labels = KMeans(k, random_state=42).fit_predict(X)
    print(f"k={k}, silhouette={silhouette_score(X, labels):.3f}")

from statsmodels.tools import add_constant
vif = [variance_inflation_factor(add_constant(X).values, i)
       for i in range(1, X.shape[1]+1)]  # VIF 共线性
```

## 19. 跨学科工具箱

```python
# Webster 信号配时 (交通工程)
def webster_timing(flow_ns, flow_ew, saturation=1800):
    Y = flow_ns / saturation + flow_ew / saturation
    C = (1.5 * 10 + 5) / (1 - Y)
    g_ns = (C - 10) * flow_ns / saturation / Y
    g_ew = (C - 10) * flow_ew / saturation / Y
    return C, g_ns, g_ew

# CVM 支付意愿 (环境经济学)
import statsmodels.api as sm
X = sm.add_constant(survey[['bid_price', 'income', 'education']])
logit = sm.Logit(survey['accept'], X).fit(disp=0)
wtp = -logit.params[0] / logit.params[1]

# TrueSkill 评分 (体育预测)
import trueskill
env = trueskill.TrueSkill(mu=25, sigma=25/3, beta=25/6, tau=25/300)
r1_new, r2_new = env.rate_1vs1(env.Rating(), env.Rating())
