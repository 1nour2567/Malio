# 可视化规范（Nature 风格）

## 核心原则

1. **图表自明** — 不看正文就能理解图在说什么。标题描述内容，图例标注完整
2. **信息密度高** — 一张好图传达 3-5 个信息点
3. **配色克制** — 2-4 色为主，避免彩虹色，红绿不并用（色盲友好）
4. **字体统一** — 全图用同一字体族，中英文混排时用等宽数字

## 配色方案

```python
# Nature 风格色板（色盲友好）
NATURE_COLORS = {
    'blue':   '#3182BD',
    'orange': '#E6550D',
    'green':  '#31A354',
    'red':    '#DE2D26',
    'purple': '#756BB1',
    'brown':  '#8C6D31',
    'pink':   '#BD4D8C',
    'gray':   '#636363',
}

# 热力图 / 连续变量
HEATMAP_CMAP = 'viridis'    # 感知均匀，打印友好
DIVERGING_CMAP = 'RdBu_r'   # 正负对比
```

## matplotlib 全局配置

```python
import matplotlib.pyplot as plt
import matplotlib
matplotlib.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'font.size': 10,
    'axes.titlesize': 11,
    'axes.labelsize': 10,
    'xtick.labelsize': 9,
    'ytick.labelsize': 9,
    'legend.fontsize': 9,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'axes.spines.top': False,      # 去上边框
    'axes.spines.right': False,    # 去右边框
    'axes.linewidth': 0.8,
    'xtick.major.width': 0.8,
    'ytick.major.width': 0.8,
})
```

### 中文字体配置

```python
import matplotlib.pyplot as plt
import matplotlib
from matplotlib.font_manager import FontProperties

# Linux / macOS
matplotlib.rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['SimHei', 'WenQuanYi Micro Hei', 'Noto Sans CJK SC', 'DejaVu Sans'],
    'axes.unicode_minus': False,  # 解决负号显示为方块
})

# Windows（SimHei 已内置，通常无需额外设置）
# matplotlib.rcParams['font.sans-serif'] = ['SimHei']

# 如果以上都不行，手动指定字体路径
# font = FontProperties(fname='/usr/share/fonts/truetype/SourceHanSansSC-Regular.otf')
# plt.title('标题', fontproperties=font)
```

## 常用图表模板

### 1. 多子图综合展示（Nature 风格）

```python
fig, axes = plt.subplots(2, 3, figsize=(12, 8))
fig.subplots_adjust(hspace=0.35, wspace=0.3)

# 图 a：综合评分排序（水平柱状图）
axes[0,0].barh(range(len(names)), scores, color=NATURE_COLORS['blue'], height=0.6)
axes[0,0].set_title('a  综合评分排序', loc='left', fontweight='bold')
axes[0,0].set_xlabel('综合评分')

# 图 b：三维评分分解（分组柱状图）
x = np.arange(len(names))
w = 0.25
axes[0,1].bar(x - w, spearman, w, label='Spearman', color=NATURE_COLORS['blue'])
axes[0,1].bar(x, mutual_info, w, label='互信息', color=NATURE_COLORS['orange'])
axes[0,1].bar(x + w, pls, w, label='PLS载荷', color=NATURE_COLORS['green'])
axes[0,1].set_title('b  三维评分分解', loc='left', fontweight='bold')
axes[0,1].legend(frameon=False, loc='upper right')

# 图 c：相关性热力图
# 图 d：风险等级分布（饼图/环形图）
# 图 e：ROC 曲线（多模型对比）
# 图 f：灵敏度分析（龙卷风图）

# 统一标注
for ax in axes.flat:
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
```

### 2. 热力图（相关性 / 混淆矩阵）

```python
import seaborn as sns
fig, ax = plt.subplots(figsize=(10, 8))
mask = np.triu(np.ones_like(corr_matrix, dtype=bool))  # 只显示下三角
sns.heatmap(corr_matrix, mask=mask, annot=True, fmt='.2f',
            cmap='RdBu_r', center=0, vmin=-1, vmax=1,
            square=True, linewidths=0.5, cbar_kws={'shrink': 0.8})
ax.set_title('特征相关性矩阵', fontweight='bold', loc='left')
```

### 3. ROC 曲线对比

```python
from sklearn.metrics import RocCurveDisplay
fig, ax = plt.subplots(figsize=(5, 5))
for name, model in models.items():
    RocCurveDisplay.from_estimator(model, X_test, y_test, ax=ax, name=name)
ax.plot([0,1], [0,1], '--', color='gray', alpha=0.5, label='随机猜测')
ax.set_xlabel('1 - 特异性')
ax.set_ylabel('敏感性')
ax.legend(frameon=False)
ax.set_title('ROC 曲线对比', fontweight='bold', loc='left')
# 标注 AUC 值在曲线旁
```

### 4. 龙卷风图（灵敏度分析）

```python
def tornado_plot(params, base_value, changes, figsize=(6, 5)):
    """灵敏度分析龙卷风图"""
    fig, ax = plt.subplots(figsize=figsize)
    impacts = []
    for param, delta in zip(params, changes):
        # 计算参数 ±delta 对输出的影响
        up = model_with_param_change(param, +delta)
        down = model_with_param_change(param, -delta)
        impacts.append({'param': param, 'low': down - base_value, 'high': up - base_value})
    
    impacts.sort(key=lambda x: max(abs(x['low']), abs(x['high'])))
    y_pos = range(len(impacts))
    ax.barh(y_pos, [i['low'] for i in impacts], color=NATURE_COLORS['blue'], label='负向扰动')
    ax.barh(y_pos, [i['high'] for i in impacts], color=NATURE_COLORS['orange'], label='正向扰动')
    ax.set_yticks(y_pos)
    ax.set_yticklabels([i['param'] for i in impacts])
    ax.axvline(x=0, color='black', linewidth=0.5)
    ax.set_xlabel('相对基准值的变化')
    ax.legend(frameon=False)
    ax.set_title('灵敏度分析', fontweight='bold', loc='left')
```

### 5. 模型架构图（三层融合示意图）

```python
# 架构图用 matplotlib.patches 手绘
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
fig, ax = plt.subplots(figsize=(8, 6))
ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis('off')

# 三个矩形层
for i, (label, color, y) in enumerate([
    ('第一层：临床规则层', NATURE_COLORS['blue'], 7),
    ('第二层：LightGBM 预测层', NATURE_COLORS['green'], 4),
    ('第三层：中医功能修正层', NATURE_COLORS['orange'], 1)
]):
    rect = FancyBboxPatch((1, y), 8, 2, boxstyle='round,pad=0.1',
                           facecolor=color, alpha=0.15, edgecolor=color, linewidth=1.5)
    ax.add_patch(rect)
    ax.text(5, y+1, label, ha='center', va='center', fontweight='bold', fontsize=11)

# 箭头
for y in [5, 2]:
    ax.annotate('', xy=(5, y+0.8), xytext=(5, y+1.2),
                arrowprops=dict(arrowstyle='->', color='gray', lw=1.5))

# 输入输出标注
ax.text(5, 9.3, '输入：多维特征', ha='center', fontsize=9, color='gray')
ax.text(5, -0.5, '输出：风险等级（高/中/低）', ha='center', fontsize=9, color='gray')
```

## 三线表（论文表格标准）

```python
def three_line_table(data, col_labels, row_labels, caption, figsize=(8, 4)):
    """绘制标准三线表"""
    fig, ax = plt.subplots(figsize=figsize)
    ax.axis('off')

    n_rows, n_cols = data.shape
    table = ax.table(cellText=data, colLabels=col_labels, rowLabels=row_labels,
                     cellLoc='center', loc='center')

    # 全局样式
    table.auto_set_font_size(False)
    table.set_fontsize(9)
    table.scale(1, 1.4)

    for key, cell in table.get_celld().items():
        cell.set_edgecolor('white')
        cell.set_linewidth(0)
        if key[0] == 0:  # 表头行
            cell.set_text_props(weight='bold')
            cell.set_facecolor('white')

    # 画三条线
    row_height = 1 / (n_rows + 1)
    top = 1 - row_height / 2
    bottom = row_height / 2
    linewidth = 1.5

    # 顶线（粗）
    ax.axhline(y=top, xmin=0.05, xmax=0.95, color='black', linewidth=linewidth * 1.5)
    # 表头底线（细）
    ax.axhline(y=top - row_height, xmin=0.05, xmax=0.95, color='black', linewidth=linewidth)
    # 底线（粗）
    ax.axhline(y=bottom, xmin=0.05, xmax=0.95, color='black', linewidth=linewidth * 1.5)

    ax.set_title(caption, fontweight='bold', loc='left', pad=12)
    return fig

# 用法
fig = three_line_table(
    data=np.array([[0.89, 0.85, 0.92], [0.76, 0.81, 0.78]]),
    col_labels=['Precision', 'Recall', 'F1'],
    row_labels=['Model A', 'Model B'],
    caption='表1  模型性能对比'
)
fig.savefig('table1.png', dpi=300, bbox_inches='tight')
```

## 保存规范

```python
# 论文用：300 DPI，TIFF 或 PDF（矢量）
fig.savefig('figure1.tiff', dpi=300, bbox_inches='tight', pil_kwargs={'compression': 'tiff_lzw'})

# PPT 用：150 DPI，PNG 透明背景
fig.savefig('figure1.png', dpi=150, bbox_inches='tight', transparent=True)

# 所有图统一编号：figure1_中文描述.png
```

## 常见错误（禁止）

- 坐标轴标签不标单位
- 图例没有意义（比如"Series 1"）
- 颜色太多（>5 种）且没有色盲友好方案
- 饼图用超过 5 个分类（改用柱状图）
- 字体太小（图上文字 < 8pt）
- 3D 图除非数据确实三维（3D 柱状图几乎永远不如 2D 分组柱状图）

---

## 美赛 MCM 图表规范

### 英文标注要点

- 标题：`Figure 1: [Descriptive title].` 或 `Figure 1. [Descriptive title].`
- 坐标轴：标单位，如 `Tourists (thousands)`, `Environmental Quality Index`
- 图例：每项有实际含义，如 `NSGA-II Optimal` 而非 `Series 1`
- 字号：标题 11pt，轴标签 10pt，刻度 9pt，图例 9pt

### 美赛常用图表额外模板

```python
# Pareto 前沿可视化 (2D 投影)
fig, axes = plt.subplots(1, 3, figsize=(14, 4))
pairs = [(0,1), (1,2), (0,2)]
labels = ['Economic ($M$)', 'Environment', 'Social']
for ax, (i, j) in zip(axes, pairs):
    ax.scatter(F_opt[:, i], F_opt[:, j], c='steelblue', alpha=0.6, s=20)
    ax.scatter(F_opt[best_idx, i], F_opt[best_idx, j],
               c='darkorange', s=80, marker='*', zorder=5, label='Selected')
    ax.set_xlabel(labels[i]); ax.set_ylabel(labels[j])
    ax.legend(frameon=False)
fig.suptitle('Pareto Front Projections', fontweight='bold')
fig.tight_layout()

# Tornado plot (英文化)
fig, ax = plt.subplots(figsize=(6, 4))
ax.barh(y_pos, low_impacts, color='#3182BD', label='Negative perturbation')
ax.barh(y_pos, high_impacts, color='#E6550D', label='Positive perturbation')
ax.set_yticks(y_pos)
ax.set_yticklabels(param_names)
ax.axvline(x=0, color='black', linewidth=0.5)
ax.set_xlabel('Change from baseline')
ax.legend(frameon=False)
ax.set_title('Sensitivity Analysis', fontweight='bold', loc='left')

# Morris µ-σ diagram
fig, ax = plt.subplots(figsize=(6, 5))
ax.scatter(mu_star, sigma, c='steelblue', s=60)
for i, name in enumerate(param_names):
    ax.annotate(name, (mu_star[i], sigma[i]), fontsize=8)
ax.set_xlabel(r'$\mu^*$ (overall influence)')
ax.set_ylabel(r'$\sigma$ (interaction/nonlinearity)')
ax.set_title('Morris Sensitivity Analysis', fontweight='bold', loc='left')
# Diagonal reference line
xmax = max(mu_star)
ax.plot([0, xmax], [0, xmax], '--', color='gray', alpha=0.5)
```

### MCM 保存规范

```python
# 论文用（提交 PDF）
fig.savefig('figure1.png', dpi=300, bbox_inches='tight')

# 所有图命名: figure1_descriptive_name.png
